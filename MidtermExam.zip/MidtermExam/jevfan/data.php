<?php

include('dbconnection.php');

$category=$_POST['institutetable'];

$sql="select course from coursetable where parent_id='".$category."'";
$result=mysqli_query($conn,$sql);

$output='<option>Select Course</option>';

while($data=mysqli_fetch_array($result))
{
	$output.="<option>".$data['course']."</option>";
}

echo $output;

?>