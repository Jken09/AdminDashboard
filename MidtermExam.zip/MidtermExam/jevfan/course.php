
<?php 
session_start();

    if(!isset($_SESSION['USER_ID'])){
        header("location:login.php");
        die();
    }
?>

<?php

include('includes/header.php'); 
include('includes/navbar.php');

?>
 <!-- Content Wrapper -->
 <div id="content-wrapper" class="d-flex flex-column">

<!-- Main Content -->
<div id="content">

    <!-- Topbar -->
    <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

        <!-- Sidebar Toggle (Topbar) -->
        <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
        </button>

        
        <!-- Topbar Navbar -->
        <ul class="navbar-nav ml-auto">

            

        

            <div class="topbar-divider d-none d-sm-block"></div>

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
                <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <span class="mr-2 d-none d-lg-inline text-gray-600 small">
                    <?php echo $_SESSION['USER_ID']; ?>
                    </span>
                    <img class="img-profile rounded-circle"
                        src="img/undraw_profile.svg">
                </a>
                <!-- Dropdown - User Information -->
                <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                    aria-labelledby="userDropdown">
                    <a class="dropdown-item" href="register.php">
                        <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                        Profile
                    </a>
                    <a class="dropdown-item" href="#">
                        <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                        Settings
                    </a>
                    <a class="dropdown-item" href="#">
                        <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                        Activity Log
                    </a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                        <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                        Logout
                    </a>
                </div>
            </li>

        </ul>

    </nav>
    <!-- End of Topbar -->


<div class="modal fade" id="addadminprofile" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Course Registration Form</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="API.php" method="POST">

        <div class="modal-body">

            <div class="form-group">
                <label> Course </label>
                <input type="text" name="course" class="form-control"  required>
            </div>
           


        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" name="courseregisterbtn" class="btn btn-primary">Save</button>
        </div>
      </form>

    </div>
  </div>
</div>

<div class="container-fluid">

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight bold text-primary">
            <button type="button" style="background:#673AB7;" class="btn btn-primary" data-toggle="modal" data-target="#addadminprofile">
                Add Course 
            </button>
            <a href="course.php">
                <button type="button" style="margin-left:300px;background:#673AB7;" class="btn btn-primary" data-toggle="modal" >
                    Refresh 
                </button>
            </a>
                
                                     
                
              
            <form action="" method="GET" class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">

                <div class="input-group" style="border: 1px solid rgb(160,160,160); border-radius:4px; margin-left:250px;">
                    <input  type="text" required value="<?php if(isset($_GET['search'])){echo $_GET['search']; } ?>" name="search" class="form-control bg-light border-0 small" placeholder="Search for..."
                        aria-label="Search" aria-describedby="basic-addon2">
                    <div class="input-group-append">
                        <button style="background:#673AB7;" class="btn btn-primary" type="submit">
                            <i class="fas fa-search fa-sm"></i>
                        </button>
                    </div>
                </div>
            </form>
        </h6>
</div>
<div class="card-body">
        <?php
            if(isset($_SESSION['status']) && $_SESSION['status']!='')
            {
                ?>
                    <script>
                        swal({
                            title: "<?php echo $_SESSION['status']?>",
                            // text: "You clicked the button!",
                            icon: "<?php echo $_SESSION['status_code'] ?>",
                            button: "OK",
                            timer: 3000,
                        });
                    </script>
                <?php
                unset($_SESSION['success']);
            }
        ?>
                <table class="table table-bordered"  id="dataTable" width="100%" cellspacing="0">
                    <thead>
                    <tr>
                        <th style="text-align: center;background: #ADD8E6;">Course</th>
                        <th style="text-align: center;background: #ADD8E6;">EDIT</th>
                        <th style="text-align: center;background: #ADD8E6;">DELETE</th>
                    </tr>
                    </thead>
                    <?php

                    $connection = mysqli_connect("localhost", "root", "", "admin");

                    if (isset($_GET['search']) && !empty($_GET['search'])) {
                        // Sanitize the search input
                        $searchInput = mysqli_real_escape_string($connection, $_GET['search']);

                        // Construct the filtered query
                        $query = "SELECT * FROM coursetable WHERE course LIKE '%$searchInput%'";
                    } else {
                        // Fetch all data when no search is performed
                        $query = "SELECT * FROM coursetable";
                    }

                    $query_run = mysqli_query($connection, $query);

                    ?>

                    <?php if (mysqli_num_rows($query_run) > 0): ?>
                        

                            <tbody>
                                <?php

                                
                    while ($row = mysqli_fetch_assoc($query_run)):
                                ?>
                        
                        <tr>
                            <td style="text-align: center;"><?php echo $row['course']; ?></td>
                            <td style="text-align: center;">
                                <form action="courseedit.php" method="POST">
                                    <input type="hidden" name="editid" value="<?php echo $row['id']; ?>">
                                    <button type="submit" name="editbtn" class="btn btn-success"> EDIT</button>
                                </form>
                            </td>
                            <td style="text-align: center;">
                                <form action="API.php" method="POST">
                                    <input type="hidden" name="deleteid" value="<?php echo $row['id']; ?>">
                                    <button type="submit" name="coursedeletebtn" class="btn btn-danger"> DELETE</button>
                                </form> 
                            </td>
                        </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <p>No Record Found.</p>
                    <?php endif; ?>
                </table>

</div>

<?php

include('includes/scripts.php');

?>