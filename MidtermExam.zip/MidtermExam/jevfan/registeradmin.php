<?php
    
    session_start();
    $connection = mysqli_connect("localhost","root","","admin");

    if(isset($_POST['registrationbtn']))
    {
        $username = $_POST['username'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $cpassword = $_POST['confirmpassword'];

        if($password === $cpassword)    
        {
            $query="INSERT INTO admintable (username,email,password) VALUES ('$username','$email','$password')";
            $query_run= mysqli_query($connection, $query);

            if($query_run)
            {
                
                $_SESSION['status'] = "Registration Successful";
                $_SESSION['status_code'] = "success";
                header('Location: login.php');
            }
            else
            {
                
                $_SESSION['status'] = "Registration Not Successful";
                $_SESSION['status_code'] = "error";
                header('Location: register.php');
            }
        }
        else
        {
            $_SESSION['status'] = "Password and Confirm Password Does Not Match";
            $_SESSION['status_code'] = "warning";
            header('Location: register.php');
        }

    }
?>