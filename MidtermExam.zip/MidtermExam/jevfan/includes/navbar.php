<!-- Sidebar -->
 <ul class="navbar-nav  sidebar sidebar-dark accordion" style="background:#673AB7"id="accordionSidebar">

<!-- Sidebar - Brand -->
<a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">
    
    
    <div>Admin Panel</div>
</a>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

<!-- Divider -->
<hr class="sidebar-divider my-0">

<!-- Nav Item - Dashboard -->
<li class="nav-item active">
    <a class="nav-link" href="index.php">
    <i class="fa-solid fa-gauge-simple"></i>
        <span>Dashboard</span></a>
</li>

<!-- Nav Item - Charts -->
<li class="nav-item active">
    <a class="nav-link" href="admin.php">
    <i class="fa-solid fa-user"></i>
        <span>Admin</span>
    </a>
</li>

<!-- Nav Item - Tables -->
<li class="nav-item active">
    <a class="nav-link" href="student.php">
        <i class="fa-solid fa-book-open-reader"></i>
        <span>Student</span></a>
</li>

<!-- Nav Item - Dashboard -->
<li class="nav-item active">
    <a class="nav-link" href="faculty.php">
        <i class="fa-solid fa-chalkboard-user"></i>
        <span>Faculty</span></a>
</li>

<!-- Nav Item - Dashboard -->
<li class="nav-item active">
    <a class="nav-link" href="subject.php">
        <i class="fa-solid fa-book-open"></i>
        <span>Subject</span></a>
</li>

<!-- Nav Item - Dashboard -->
<li class="nav-item active">
    <a class="nav-link" href="institute.php">
        <i class="fa-solid fa-building"></i>
        <span>Institute</span></a>
        <!-- Nav Item - Dashboard -->
<li class="nav-item active">
    <a class="nav-link" href="course.php">
    <i class='fas fa-book'></i>
        <span>Course</span></a>
</li>
<li class="nav-item active">
    <a class="nav-link" href="institute.php">
        <span></span></a>
</li>
<li class="nav-item active">
    <a class="nav-link" href="institute.php">
        <span></span></a>
</li>


<!-- Divider -->
<hr class="sidebar-divider d-none d-md-block">

<!-- Sidebar Toggler (Sidebar) -->
<div class="text-center d-none d-md-inline">
    <button class="rounded-circle border-0" id="sidebarToggle"></button>
</div>



</ul>
<!-- End of Sidebar -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
</a>

 <!-- Logout Modal-->
 <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true"></span>
                    </button>   
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>



