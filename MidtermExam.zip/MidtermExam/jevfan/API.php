

<?php
    session_start();

    $connection = mysqli_connect("localhost","root","","admin");

    if(isset($_POST['adminregisterbtn']))
    {
        $username = $_POST['username'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $cpassword = $_POST['confirmpassword'];

        if($password === $cpassword)    
        {
            $query="INSERT INTO admintable (username,email,password) VALUES ('$username','$email','$password')";
            $query_run= mysqli_query($connection, $query);

            if($query_run)
            {
                
                $_SESSION['status'] = "Admin Added";
                $_SESSION['status_code'] = "success";
                header('Location: admin.php');
            }
            else
            {
                
                $_SESSION['status'] = "Admin Not Added";
                $_SESSION['status_code'] = "error";
                header('Location: admin.php');
            }
        }
        else
        {
            $_SESSION['status'] = "Password and Confirm Password Does Not Match";
            $_SESSION['status_code'] = "warning";
            header('Location: admin.php');
        }

    }


    if(isset($_POST['adminupdatebtn']))
    {   
        $id = $_POST['editid'];
        $username = $_POST['editusername'];
        $email = $_POST['editemail'];
        $password = $_POST['editpassword'];

        $query = "UPDATE admintable SET username='$username',
        email = '$email', password='$password' WHERE id='$id'";
        $query_run = mysqli_query($connection, $query);

        if($query_run){
            $_SESSION['status']  = "Data is Updated";
            $_SESSION['status_code'] = "success";
            header('Location: admin.php');
        }
        else
        {
            $_SESSION['status'] = "Data is NOT Updated";
            $_SESSION['status_code'] = "error";
            header('Location: admin.php');
        }

    }

    if(isset($_POST['admindeletebtn']))
    {

        $id = $_POST['deleteid'];

        $query = "DELETE FROM admintable WHERE id ='$id' ";
        $query_run = mysqli_query($connection,$query);

        if($query_run)
        {
            $_SESSION['status'] = "Data is DELETED";
             $_SESSION['status_code'] = "success";
            header('Location:admin.php');
        }
        else{
            $_SESSION['status'] = "Data is NOT DELETED";
            $_SESSION['status_code'] = "error";
            header('Location:admin.php');
        }

    }

    if(isset($_POST['courseregisterbtn']))
{
    $parent_id = $_POST['institute'];
    $course = $_POST['course'];
    
    

        $query="INSERT INTO coursetable(parent_id, course) VALUES ('$parent_id','$course')";
        $query_run= mysqli_query($connection, $query);

        if($query_run)
        {
            
            $_SESSION['status'] = "Course Added";
            $_SESSION['status_code'] = "success";
            header('Location: course.php');
        }
        else
        {
            
            $_SESSION['status'] = "Course Not Added";
            $_SESSION['status_code'] = "error";
            header('Location:  course.php');
        }


    
}

if(isset($_POST['courseupdatebtn']))
{   
    $id = $_POST['editid'];
    $course = $_POST['editcourse'];
    

    $query = "UPDATE coursetable SET 
    course='$course'
     WHERE id='$id'";
     
    $query_run = mysqli_query($connection, $query);

    if($query_run){
        $_SESSION['status'] = "Data is Updated";
        $_SESSION['status_code'] = "success";
        header('Location: course.php');
    }
    else
    {
        $_SESSION['status'] = "Data is NOT Updated";
        $_SESSION['status_code'] = "error";
        header('Location: course.php');
    }

}


if(isset($_POST['coursedeletebtn']))
{

    $id = $_POST['deleteid'];

    $query = "DELETE FROM coursetable WHERE id ='$id' ";
    $query_run = mysqli_query($connection,$query);

    if($query_run)
    {
        $_SESSION['status'] = "Data is DELETED";
        $_SESSION['status_code'] = "success";
        header('Location:course.php');
    }
    else{
        $_SESSION['status'] = "Data is NOT DELETED";
        $_SESSION['status_code'] = "error";
        header('Location:course.php');
    }

}

if(isset($_POST['facultyregisterbtn']))
{
    $firstname = $_POST['firstname'];
    $middlename = $_POST['middlename'];
    $lastname = $_POST['lastname'];
    $dateofbirth = $_POST['dateofbirth'];
    $gender = $_POST['gender'];
    $institute = $_POST['institute'];
    $course = $_POST['course'];
    $contactnumber = $_POST['contactnumber'];
    
        $query="INSERT INTO facultytable(firstname, middlename, lastname, dateofbirth,gender,institute,course,contactnumber ) 
        VALUES ('$firstname','$middlename','$lastname','$dateofbirth','$gender','$institute','$course','$contactnumber')";
        $query_run= mysqli_query($connection, $query);

        if($query_run)
        {
            
            $_SESSION['status'] = "Faculty Added";
            $_SESSION['status_code'] = "success";
            header('Location: faculty.php');
        }
        else
        {
            
            $_SESSION['status'] = "Faculty Not Added";
            $_SESSION['status_code'] = "error";
            header('Location: faculty.php');
        }
}




if(isset($_POST['facultyupdatebtn']))
{   
    $id = $_POST['editid'];
    $firstname = $_POST['editfirstname'];
    $middlename = $_POST['editmiddlename'];
    $lastname = $_POST['editlastname'];
    $dateofbirth = $_POST['editdateofbirth'];
    $gender = $_POST['editgender'];
    $institute = $_POST['editinstitute'];
    $course = $_POST['editcourse'];
    $contactnumber = $_POST['editcontactnumber'];

    $query = "UPDATE facultytable SET firstname='$firstname',
     middlename = '$middlename', lastname='$lastname',
     dateofbirth='$dateofbirth', gender='$gender', institute='$institute', 
     course='$course', contactnumber='$contactnumber' WHERE id='$id'";
     
    $query_run = mysqli_query($connection, $query);

    if($query_run){
        $_SESSION['status'] = "Data is Updated";
        $_SESSION['status_code'] = "success";
        header('Location: faculty.php');
    }
    else
    {
        $_SESSION['status'] = "Data is NOT Updated";
        $_SESSION['status_code'] = "warning";
        header('Location: faculty.php');
    }

}
    

if(isset($_POST['facultydeletebtn']))
{

    $id = $_POST['deleteid'];

    $query = "DELETE FROM facultytable WHERE id ='$id' ";
    $query_run = mysqli_query($connection,$query);

    if($query_run)
    {
        $_SESSION['status'] = "Data is DELETED";
        $_SESSION['status_code'] = "success";
        header('Location:faculty.php');
    }
    else{
        $_SESSION['status'] = "Data is NOT DELETED";
        $_SESSION['status_code'] = "error";
        header('Location:faculty.php');
    }

}

if(isset($_POST['instituteregisterbtn']))
{
    $institute = $_POST['institute'];
    

    
        $query="INSERT INTO institutetable(institute) VALUES ('$institute')";
        $query_run= mysqli_query($connection, $query);

        if($query_run)
        {
            
            $_SESSION['status'] = "Institute Added";
            $_SESSION['status_code'] = "success";
            header('Location: institute.php');
        }
        else
        {
            
            $_SESSION['status'] = "Institute Not Added";
            $_SESSION['status_code'] = "error";
            header('Location: institute.php');
        }
       
}


if(isset($_POST['instituteupdatebtn']))
{   
    $id = $_POST['editid'];
    $institute = $_POST['editinstitute'];
    

    $query = "UPDATE institutetable SET 
    institute='$institute'
     WHERE id='$id'";
     
    $query_run = mysqli_query($connection, $query);

    if($query_run){
        $_SESSION['status'] = "Data is Updated";
        $_SESSION['status_code'] = "success";
        header('Location: institute.php');
    }
    else
    {
        $_SESSION['status'] = "Data is NOT Updated";
        $_SESSION['status_code'] = "error";
        header('Location: institute.php');
    }

}


if(isset($_POST['institutedeletebtn']))
{

    $id = $_POST['deleteid'];

    $query = "DELETE FROM institutetable WHERE id ='$id' ";
    $query_run = mysqli_query($connection,$query);

    if($query_run)
    {
        $_SESSION['status'] = "Data is DELETED";
        $_SESSION['status_code'] = "success";
        header('Location:institute.php');
    }
    else{
        $_SESSION['status'] = "Data is NOT DELETED";
        $_SESSION['status_code'] = "error";
        header('Location:institute.php');
    }

}

if(isset($_POST['studentregisterbtn']))
{   
    $studentnumber = $_POST['studentnumber'];
    $firstname = $_POST['firstname'];
    $middlename = $_POST['middlename'];
    $lastname = $_POST['lastname'];
    $dateofbirth = $_POST['dateofbirth'];
    $gender = $_POST['gender'];
    $province = $_POST['province'];
    $municipality = $_POST['municipality'];
    $barangay = $_POST['barangay'];
    $purok = $_POST['purok'];
    $zipcode = $_POST['zipcode'];
    $contactnumber = $_POST['contactnumber'];
    $institute = $_POST['institute'];
    $course = $_POST['course'];
    $nameofguardian = $_POST['nameofguardian'];
    $emcontactnumber = $_POST['emcontactnumber'];
    $address = $_POST['address'];

    
        $query="INSERT INTO studenttable(studentnumber,firstname, middlename, lastname,
         dateofbirth,gender,province,municipality,barangay,purok,zipcode,contactnumber,
         institute,course,nameofguardian,emcontactnumber,address) 
        VALUES ('$studentnumber','$firstname','$middlename','$lastname','$dateofbirth','$gender',
        '$province','$municipality','$barangay','$purok','$zipcode','$contactnumber','$institute',
        '$course','$nameofguardian','$emcontactnumber','$address')";
        $query_run= mysqli_query($connection, $query);

        if($query_run)
        {
            
            $_SESSION['status'] = "Student Added";
            $_SESSION['status_code'] = "success";
            header('Location: student.php');
        }
        else
        {
            
            $_SESSION['status'] = "Student Not Added";
            $_SESSION['status_code'] = "error";
            header('Location: student.php');
        }
}




if(isset($_POST['studentupdatebtn']))
{   
    $id = $_POST['editid'];
    $studentnumber = $_POST['editstudentnumber'];
    $firstname = $_POST['editfirstname'];
    $middlename = $_POST['editmiddlename'];
    $lastname = $_POST['editlastname'];
    $dateofbirth = $_POST['editdateofbirth'];
    $gender = $_POST['editgender'];
    $province = $_POST['editprovince'];
    $municipality = $_POST['editmunicipality'];
    $barangay = $_POST['editbarangay'];
    $purok = $_POST['editpurok'];
    $zipcode = $_POST['editzipcode'];
    $contactnumber = $_POST['editcontactnumber'];
    $institute = $_POST['editinstitute'];
    $course = $_POST['editcourse'];
    $nameofguardian = $_POST['editnameofguardian'];
    $emcontactnumber = $_POST['editemcontactnumber'];
    $address = $_POST['editaddress'];

    $query = "UPDATE studenttable SET
    studentnumber = '$studentnumber',
    firstname = '$firstname',
    middlename = '$middlename',
    lastname = '$lastname',
    dateofbirth = '$dateofbirth',
    gender = '$gender',
    province = '$province',
    municipality = '$municipality',
    barangay = '$barangay',
    purok = '$purok',
    zipcode = '$zipcode',
    contactnumber = '$contactnumber',
    institute = '$institute',
    course = '$course',
    nameofguardian = '$nameofguardian',
    emcontactnumber = '$emcontactnumber',
    address = '$address'
    WHERE id='$id'";
     
    $query_run = mysqli_query($connection, $query);

    if($query_run){
        $_SESSION['status'] = "Data is Updated";
        $_SESSION['status_code'] = "success";
        header('Location: student.php');
    }
    else
    {
        $_SESSION['status'] = "Data is NOT Updated";
        $_SESSION['status_code'] = "error";
        header('Location: student.php');
    }

}


if(isset($_POST['studentdeletebtn']))
{

    $id = $_POST['deleteid'];

    $query = "DELETE FROM studenttable WHERE id ='$id' ";
    $query_run = mysqli_query($connection,$query);

    if($query_run)
    {
        $_SESSION['status'] = "Data is DELETED";
        $_SESSION['status_code'] = "success";
        header('Location:student.php');
    }
    else{
        $_SESSION['status'] = "Data is NOT DELETED";
        $_SESSION['status_code'] = "error";
        header('Location:student.php');
    }

}

if(isset($_POST['subjectregisterbtn']))
{
$code = $_POST['code'];
$description = $_POST['description'];
$unit = $_POST['unit'];
$type = $_POST['type'];

$query="INSERT INTO subjecttable(code,description,unit,type) VALUES ('$code','$description','$unit','$type')";
$query_run= mysqli_query($connection, $query);

if($query_run)
{
    $_SESSION['status'] = "Subject Added";
    $_SESSION['status_code'] = "success";
    header('Location: subject.php');
}
else
{
    $_SESSION['status'] = "Subject Not Added";
    $_SESSION['status_code'] = "error";
    header('Location: subject.php');
}
}

if(isset($_POST['subjectupdatebtn']))
{   
$id = $_POST['editid'];
$institute = $_POST['editinstitute'];


$query = "UPDATE institutetable SET 
institute='$institute'
 WHERE id='$id'";
 
$query_run = mysqli_query($connection, $query);

if($query_run){
    $_SESSION['status'] = "Data is Updated";
    $_SESSION['status_code'] = "success";
    header('Location: subject.php');
}
else
{
    $_SESSION['status'] = "Data is NOT Updated";
    $_SESSION['status_code'] = "error";
    header('Location: subject.php');
}

}



if(isset($_POST['subjectdeletebtn']))
{

$id = $_POST['deleteid'];

$query = "DELETE FROM subjecttable WHERE id ='$id' ";
$query_run = mysqli_query($connection,$query);

if($query_run)
{
    $_SESSION['status'] = "Data is DELETED";
    $_SESSION['status_code'] = "success";
    header('Location:subject.php');
}
else{
    $_SESSION['status'] = "Data is NOT DELETED";
    $_SESSION['status_code'] = "error";
    header('Location:subject.php');
}

}

if(isset($_POST['instituteregisterbtn']))
{
    $institute = $_POST['institute'];
    

    
        $query="INSERT INTO institutetable(institute) VALUES ('$institute')";
        $query_run= mysqli_query($connection, $query);

        if($query_run)
        {
            
            $_SESSION['status'] = "Institute Added";
            $_SESSION['status_code'] = "success";
            header('Location: institute.php');
        }
        else
        {
            
            $_SESSION['status'] = "Institute Not Added";
            $_SESSION['status_code'] = "error";
            header('Location: institute.php');
        }
       
}


if(isset($_POST['instituteupdatebtn']))
{   
    $id = $_POST['editid'];
    $institute = $_POST['editinstitute'];
    

    $query = "UPDATE institutetable SET 
    institute='$institute'
     WHERE id='$id'";
     
    $query_run = mysqli_query($connection, $query);

    if($query_run){
        $_SESSION['status'] = "Data is Updated";
        $_SESSION['status_code'] = "success";
        header('Location: institute.php');
    }
    else
    {
        $_SESSION['status'] = "Data is NOT Updated";
        $_SESSION['status_code'] = "error";
        header('Location: institute.php');
    }

}


if(isset($_POST['institutedeletebtn']))
{

    $id = $_POST['deleteid'];

    $query = "DELETE FROM institutetable WHERE id ='$id' ";
    $query_run = mysqli_query($connection,$query);

    if($query_run)
    {
        $_SESSION['status'] = "Data is DELETED";
        $_SESSION['status_code'] = "success";
        header('Location:institute.php');
    }
    else{
        $_SESSION['status'] = "Data is NOT DELETED";
        $_SESSION['status_code'] = "error";
        header('Location:institute.php');
    }

}



?>