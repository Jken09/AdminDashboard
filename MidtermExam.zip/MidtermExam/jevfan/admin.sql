-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 19, 2023 at 01:17 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `admin`
--

-- --------------------------------------------------------

--
-- Table structure for table `registeradmin`
--

CREATE TABLE `registeradmin` (
  `id` int(30) NOT NULL,
  `username` varchar(75) NOT NULL,
  `email` varchar(80) NOT NULL,
  `password` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `registeradmin`
--

INSERT INTO `registeradmin` (`id`, `username`, `email`, `password`) VALUES
(39, 'jervin10', 'jervin10@gmail.com', 'jervin1019'),
(40, 'angelieF12', 'angelieF12@gmail.com', 'angelieflores10');

-- --------------------------------------------------------

--
-- Table structure for table `registercourse`
--

CREATE TABLE `registercourse` (
  `id` int(30) NOT NULL,
  `parent_id` int(30) NOT NULL,
  `course` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `registercourse`
--

INSERT INTO `registercourse` (`id`, `parent_id`, `course`) VALUES
(44, 27, 'Bachelor of Science in Biology'),
(45, 27, 'Bachelor of Science in Environmental Science'),
(46, 27, 'Bachelor of Science in Agricultural Management'),
(47, 27, 'Bachelor of Science in Horticulture (BSH)'),
(48, 27, 'Bachelor of Science in Agriculture (BSA)'),
(49, 32, 'Bachelor of Science in Information Technology');

-- --------------------------------------------------------

--
-- Table structure for table `registerfaculty`
--

CREATE TABLE `registerfaculty` (
  `id` int(30) NOT NULL,
  `firstname` varchar(70) NOT NULL,
  `middlename` varchar(70) NOT NULL,
  `lastname` varchar(70) NOT NULL,
  `dateofbirth` date NOT NULL,
  `gender` enum('Male','Female','Prefer not to say') NOT NULL,
  `institute` varchar(80) NOT NULL,
  `course` varchar(80) NOT NULL,
  `contactnumber` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `registerfaculty`
--

INSERT INTO `registerfaculty` (`id`, `firstname`, `middlename`, `lastname`, `dateofbirth`, `gender`, `institute`, `course`, `contactnumber`) VALUES
(13, 'Cindy', 'Almosura', 'Lasco', '2023-11-01', 'Female', 'Institute of Computing and Engineering', 'Bachelor of Science in Information Technology', 2147483647),
(14, 'Lanie', 'Balbuena', 'Laureano', '2023-11-22', 'Female', 'Institute of Computing and Engineering', 'Bachelor of Science in Biology', 2147483647),
(15, 'Dony ', 'Cueco', 'Dongiapon', '2023-11-01', 'Male', 'Institute of Computing and Engineering', 'Bachelor of Science in Information Technology', 2147483647),
(16, 'Jhon', 'Eno', 'Inoco', '2023-11-04', 'Male', 'Institute of Computing and Engineering', 'Bachelor of Science in Information Technology', 2147483647);

-- --------------------------------------------------------

--
-- Table structure for table `registerinstitute`
--

CREATE TABLE `registerinstitute` (
  `id` int(30) NOT NULL,
  `institute` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `registerinstitute`
--

INSERT INTO `registerinstitute` (`id`, `institute`) VALUES
(27, 'Institute of Agricultural and Life Sciences'),
(28, 'Faculty of Teacher Education (FTEd)'),
(29, 'Institute of Business and Public Administration (IBPA'),
(30, 'Institute of Education and Teacher Training (IETT)'),
(31, 'Institute of Nursing and Allied Health Sciences (FNAHS)'),
(32, 'Institute of Computing and Engineering'),
(33, 'Institute of General Education (IGE)');

-- --------------------------------------------------------

--
-- Table structure for table `registerstudent`
--

CREATE TABLE `registerstudent` (
  `id` int(30) NOT NULL,
  `studentnumber` varchar(50) NOT NULL,
  `firstname` varchar(70) NOT NULL,
  `middlename` varchar(70) NOT NULL,
  `lastname` varchar(70) NOT NULL,
  `dateofbirth` date NOT NULL,
  `gender` enum('Male','Female','Prefer not to say') NOT NULL,
  `province` varchar(70) NOT NULL,
  `municipality` varchar(70) NOT NULL,
  `barangay` varchar(70) NOT NULL,
  `purok` varchar(80) NOT NULL,
  `zipcode` int(50) NOT NULL,
  `contactnumber` int(60) NOT NULL,
  `institute` varchar(80) NOT NULL,
  `course` varchar(80) NOT NULL,
  `nameofguardian` varchar(80) NOT NULL,
  `emcontactnumber` int(60) NOT NULL,
  `address` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `registerstudent`
--

INSERT INTO `registerstudent` (`id`, `studentnumber`, `firstname`, `middlename`, `lastname`, `dateofbirth`, `gender`, `province`, `municipality`, `barangay`, `purok`, `zipcode`, `contactnumber`, `institute`, `course`, `nameofguardian`, `emcontactnumber`, `address`) VALUES
(16, '2021-2311', 'Jade', 'Candia', 'Sasiang', '2023-11-10', 'Male', 'Davao Oriental', 'Governor Generoso', 'Tibanban', 'Prk 2', 8200, 2147483647, 'Institute of Agricultural and Life Sciences', 'Bachelor of Science in Environmental Science', 'Ruben Sasiang', 93010291, 'Prk. 2 Tibanban, Governor Generoso'),
(17, '2021-2019', 'Angelie', 'Perdez', 'Bernadit', '2023-11-02', 'Female', 'Davao De Oro', 'Maragusan', 'Mapawa', 'Prk. 8', 8800, 2147483647, 'Institute of Agricultural and Life Sciences', 'Bachelor of Science in Agricultural Management', 'Rosalinda Bernadit', 2147483647, 'Prk. 8 Mapawa, Maragusan');

-- --------------------------------------------------------

--
-- Table structure for table `registersubject`
--

CREATE TABLE `registersubject` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `description` varchar(80) NOT NULL,
  `unit` smallint(20) NOT NULL,
  `type` enum('Lecture','Laboratory') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `registersubject`
--

INSERT INTO `registersubject` (`id`, `code`, `description`, `unit`, `type`) VALUES
(12, 'ITP 130', 'Social & Professional Issues', 3, 'Lecture'),
(13, 'ITP 131', 'Networking 2', 3, 'Laboratory'),
(14, 'ITPE 130', 'Integrative Programming & Technologies 2', 3, 'Laboratory'),
(15, 'ITP 133', 'Systems Integration & Architecture 1', 3, 'Laboratory');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `registeradmin`
--
ALTER TABLE `registeradmin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registercourse`
--
ALTER TABLE `registercourse`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registerfaculty`
--
ALTER TABLE `registerfaculty`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registerinstitute`
--
ALTER TABLE `registerinstitute`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registerstudent`
--
ALTER TABLE `registerstudent`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registersubject`
--
ALTER TABLE `registersubject`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `registeradmin`
--
ALTER TABLE `registeradmin`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `registercourse`
--
ALTER TABLE `registercourse`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `registerfaculty`
--
ALTER TABLE `registerfaculty`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `registerinstitute`
--
ALTER TABLE `registerinstitute`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `registerstudent`
--
ALTER TABLE `registerstudent`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `registersubject`
--
ALTER TABLE `registersubject`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
