<?php 
session_start();

    if(!isset($_SESSION['USER_ID'])){
        header("location:login.php");
        die();
    }
?>

<?php

include('includes/header.php'); 
include('includes/navbar.php');

?>

 <!-- Content Wrapper -->
 <div id="content-wrapper" class="d-flex flex-column">

<!-- Main Content -->
<div id="content">

    <!-- Topbar -->
    <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

        <!-- Sidebar Toggle (Topbar) -->
        <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
        </button>


        <!-- Topbar Navbar -->
        <ul class="navbar-nav ml-auto">

            <!-- Nav Item - Search Dropdown (Visible Only XS) -->
            <li class="nav-item dropdown no-arrow d-sm-none">
                <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button"
                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fas fa-search fa-fw"></i>
                </a>
                <!-- Dropdown - Messages -->
                <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                    aria-labelledby="searchDropdown">
                    <form class="form-inline mr-auto w-100 navbar-search">
                        <div class="input-group">
                            <input type="text" class="form-control bg-light border-0 small"
                                placeholder="Search for..." aria-label="Search"
                                aria-describedby="basic-addon2">
                            <div class="input-group-append">
                                <button class="btn btn-primary" type="button">
                                    <i class="fas fa-search fa-sm"></i>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </li>

            

        

            <div class="topbar-divider d-none d-sm-block"></div>

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
                <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <span class="mr-2 d-none d-lg-inline text-gray-600 small">
                    <?php echo $_SESSION['USER_ID']; ?>
                    </span>
                    <img class="img-profile rounded-circle"
                        src="img/undraw_profile.svg">
                </a>
                <!-- Dropdown - User Information -->
                <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                    aria-labelledby="userDropdown">
                    <a class="dropdown-item" href="register.php">
                        <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                        Profile
                    </a>
                    <a class="dropdown-item" href="#">
                        <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                        Settings
                    </a>
                    <a class="dropdown-item" href="#">
                        <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                        Activity Log
                    </a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                        <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                        Logout
                    </a>
                </div>
            </li>

        </ul>

    </nav>
    <!-- End of Topbar -->


<div class="modal fade" id="addadminprofile" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Admin Registration</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      

    </div>
  </div>
</div>


<div class="container-fluid">

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight bold text-primary">
                Edit Faculty Information
        </h6>
</div>
<div class="card-body">
<?php

    $connection = mysqli_connect("localhost","root","","admin");
    if(isset($_POST['editbtn']))
    {
        $id = $_POST['editid'];

        $query = "SELECT * FROM facultytable WHERE id = '$id'";
        $query_run = mysqli_query($connection,$query);

        foreach($query_run as $row)
            $gender = $row['gender'];
        {
            ?>


        <form action="API.php" method="POST">
            <input type="hidden" name="editid" value="<?php echo $row['id'] ?>">
            <div class="form-group">
                <label> First Name </label>
                <input type="text" name="editfirstname" class="form-control" value="<?php echo $row['firstname'] ?>"  required>
            </div>
            <div class="form-group">
                <label> Middle Name </label>
                <input type="text" name="editmiddlename" class="form-control" value="<?php echo $row['middlename'] ?>"  required>
            </div>
            <div class="form-group">
                <label> Last Name </label>
                <input type="text" name="editlastname" class="form-control" value="<?php echo $row['lastname'] ?>"  required>
            </div>
            <div class="form-group">
                <label>Date of Birth</label>
                <input type="date" name="editdateofbirth" class="form-control" value="<?php echo $row['dateofbirth'] ?>" required>
            </div>

            <label>Gender</label>
            <div>
                
                <input type="radio" id="lecture" name="editgender" value="Male" <?php if ($gender == "Male") { echo "checked"; } ?> required >
                <label for="laboratory" style="margin-right: 50px;">Male</label>
            
            
                <input type="radio" id="laboratory" name="editgender" value="Female" <?php if ($gender == "Female") { echo "checked"; } ?>  required>
                <label for="laboratory" style="margin-right: 50px;">Female</label>

                <input type="radio" id="laboratory" name="editgender" value="Prefer not to say" <?php if ($gender == "Prefer not to say") { echo "checked"; } ?>  required>
                <label for="laboratory">Prefer not to say</label>
            </div>
            <div class="form-group">
                <label style="margin-right: 50px;">Institute</label></br>

                <select style="width: 1035px; height: 40px; border-radius:5px;border:1.3px solid rgb(216,216,216)" name="editinstitute">
                <?php
                    include('dbconnection.php');
                    $categories = mysqli_query($con,"SELECT * FROM institutetable");
                    while($c = mysqli_fetch_array($categories)){

                ?>

                <option value="<?php echo $c['institute'] ?>" <?php if ($c['institute'] == $row['institute']) { echo 'selected'; } ?>><?php echo $c['institute'] ?></option>
                <?php } ?>
                </select>
            </div>
            <div class="form-group">
                <label style="margin-right: 50px;">Course</label></br>

                <select style="width: 1035px; height: 40px; border-radius:5px;border:1.3px solid rgb(216,216,216)" name="editcourse">
                <?php
                    include('dbconnection.php');
                    $categories = mysqli_query($con,"SELECT * FROM coursetable");
                    while($c = mysqli_fetch_array($categories)){

                ?>

                <option value="<?php echo $c['course'] ?>" <?php if ($c['course'] == $row['institute']) { echo 'selected'; } ?>><?php echo $c['course'] ?></option>
                <?php } ?>
                </select>
            </div>

            <div class="form-group">
                <label>Contact Number</label>
                <input type="number" name="editcontactnumber" value="<?php echo $row['contactnumber'] ?>" class="form-control" required>
            </div>

            <a href="faculty.php" class="btn btn-danger" style="margin-right:30px;">Cancel</a>
            <button type="submit" name="facultyupdatebtn" class="btn btn-primary">Update</button>

            </form>


    <?php
    }
}
?>

    </div>
    </div>
</div>

</div>

<?php

include('includes/scripts.php');



?>