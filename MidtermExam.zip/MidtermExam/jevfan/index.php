<?php 
session_start();

    if(!isset($_SESSION['USER_ID'])){
        header("location:login.php");
        die();
    }
?>

<?php

include('includes/header.php'); 
include('includes/navbar.php');

?>





        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                    
                 

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    
                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        

                       
                    

                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small">

                                    <?php echo $_SESSION['USER_ID']; ?>

                                </span>
                                <img class="img-profile rounded-circle"
                                    src="img/undraw_profile.svg">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Profile
                                </a>
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Settings
                                </a>
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Activity Log
                                </a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">&nbsp;&nbsp;&nbsp;&nbsp;Dashboard</h1>
                        
                    </div>

                    <!-- Content Row -->
                    <div class="row">

                        
                        <div class="col-xl-3 col-md-6 mb-4" style="margin-right: 100px;margin-left:40px;">
                            <div class="card border-left-primary shadow h-100 py-2" >
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                Number of Admin</div>
                                            
                                                <?php
                                                    $connection = mysqli_connect("localhost","root","","admin");

                                                    $query = "SELECT id FROM admintable ORDER BY id";
                                                    $query_run = mysqli_query($connection,$query);

                                                    $row = mysqli_num_rows($query_run);

                                                    echo '<h3>&nbsp;&nbsp;'.$row.'</h3>';
                                                ?>

                                        </div>
                                        <div class="col-auto">
                                            <i class='fa-solid fa-user' style='font-size: 35px;color:#673AB7;'></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        
                        <div class="col-xl-3 col-md-6 mb-4" style="margin-right: 100px;">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                                NUmber of Student</div>
                                       

                                                <?php
                                                    $connection = mysqli_connect("localhost","root","","admin");

                                                    $query = "SELECT id FROM studenttable ORDER BY id";
                                                    $query_run = mysqli_query($connection,$query);

                                                    $row = mysqli_num_rows($query_run);

                                                    echo '<h3>&nbsp;&nbsp;'.$row.'</h3>';
                                                ?>



                                        </div>
                                        <div class="col-auto">
                                            <i class='fa-solid fa-book-open-reader' style='font-size: 35px;color:#673AB7;'></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-info shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Number of Faculty
                                            </div>
                                            <div class="row no-gutters align-items-center">
                                                <div class="col-auto">
                                                    
                                                <?php
                                                    $connection = mysqli_connect("localhost","root","","admin");

                                                    $query = "SELECT id FROM facultytable ORDER BY id";
                                                    $query_run = mysqli_query($connection,$query);

                                                    $row = mysqli_num_rows($query_run);

                                                    echo '<h3>&nbsp;&nbsp;'.$row.'</h3>';
                                                ?>

                                                </div>
                                                <div class="col">
                                                        <div class="progress-bar bg-info" role="progressbar"
                                                            style="width: 50%" aria-valuenow="50" aria-valuemin="0"
                                                            aria-valuemax="100"></div>
                                                    
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class='fa-solid fa-chalkboard-user' style='font-size: 35px;color:#673AB7;'></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                       

                       
                    </div>
                    <div class="row">

                        
                        <div class="col-xl-3 col-md-6 mb-4" style="margin-right: 100px;margin-left:40px;margin-top:50px;">
                            <div class="card border-left-primary shadow h-100 py-2" >
                                <div class="card-body" >
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                number of subject</div>
                                            
                                                <?php
                                                    $connection = mysqli_connect("localhost","root","","admin");

                                                    $query = "SELECT id FROM subjecttable ORDER BY id";
                                                    $query_run = mysqli_query($connection,$query);

                                                    $row = mysqli_num_rows($query_run);

                                                    echo '<h3>&nbsp;&nbsp;'.$row.'</h3>';
                                                ?>
                                        </div>
                                        <div class="col-auto">
                                            <i class='fa-solid fa-book-open' style='font-size: 35px;color:#673AB7;'></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        
                        <div class="col-xl-3 col-md-6 mb-4" style="margin-right: 100px;margin-top:50px;">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                                Number Of course</div>
                                            
                                                <?php
                                                    $connection = mysqli_connect("localhost","root","","admin");

                                                    $query = "SELECT id FROM coursetable ORDER BY id";
                                                    $query_run = mysqli_query($connection,$query);

                                                    $row = mysqli_num_rows($query_run);

                                                    echo '<h3>&nbsp;&nbsp;'.$row.'</h3>';
                                                ?>
                                        </div>
                                        <div class="col-auto">
                                            <i class='fas fa-book' style='font-size: 35px;color:#673AB7;'></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        
                        <div class="col-xl-3 col-md-6 mb-4" style="margin-top:50px;">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                                Number Of institute</div>
                                            
                                                <?php
                                                    $connection = mysqli_connect("localhost","root","","admin");

                                                    $query = "SELECT id FROM institutetable ORDER BY id";
                                                    $query_run = mysqli_query($connection,$query);

                                                    $row = mysqli_num_rows($query_run);

                                                    echo '<h3>&nbsp;&nbsp;'.$row.'</h3>';
                                                ?>
                                        </div>
                                        <div class="col-auto">
                                            <i class='fa-solid fa-building' style='font-size: 35px;color:#673AB7;'></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                       
                    </div>

                    

                    <!-- Content Row -->



                    
                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->


<?php
include('includes/scripts.php');
include('includes/footer.php');
?>



   

